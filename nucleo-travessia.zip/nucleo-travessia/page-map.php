<?php
/*	Template Name: Página de Mapa
 * 
 * 
 * */

?>

<?php get_header(); ?>
</div>
<div class="row">
	<div class="col-md-12">
		<?php 
			if ( is_user_logged_in() ){							 ?>
				<?php if (have_posts()): while(have_posts()) : the_post(); ?>				
			<div class="entry-content map-content">
				<?php the_content(); ?>
			</div>			
			<?php endwhile; else: ?>
				<p><?php _e('Desculpe, não há posts a exibir.'); ?></p>
			<?php endif; 
			} else { ?>
				<p>é necessari fazer login</p>
				<?php
			}
        ?>		
		
			
	</div>
</div>        
<br>  
<div>
<?php get_footer(); ?>
